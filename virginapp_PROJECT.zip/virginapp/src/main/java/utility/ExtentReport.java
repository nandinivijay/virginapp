package utility;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReport {
	
    // Create global variable which will be used in all method
	 public static ExtentReports extent;
	public  static ExtentTest logger;
	 

	public ExtentReport() {
		// TODO Auto-generated constructor stub
	}
	
    // This code will run before executing any testcase
	@BeforeMethod
	public void setup()
	{
	    ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/learn_automation2.html");
		
	    extent = new ExtentReports();
	    
	    extent.attachReporter(reporter);
	    
	    
	}
	public static ExtentTest createTest(String name) {
		logger=extent.createTest("LoginTest");
		return logger;
	}
		
@AfterSuite
public void publish() {
	extent.flush();
}

}
